package com.example.locationproject.DataAppPackage;

import java.io.Serializable;

public class Photos implements Serializable {

    private String photo_reference;

    public String getPhoto_reference() {
        return photo_reference;
    }

    public void setPhoto_reference(String photo_reference) {
        this.photo_reference = photo_reference;
    }

}
