package com.example.locationproject.MapsDataPackage;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;

import com.example.locationproject.DataAppPackage.MapModel;
import com.example.locationproject.R;

public class ActivityFavorites extends AppCompatActivity implements SearchInterface {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("LocationApp");

        FragmentFavorites fragmentFavorites = new FragmentFavorites();
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragmentFavoritesContainer, fragmentFavorites);
        fragmentTransaction.commit();
    }

    @Override
    public void onLocationItemClick(MapModel mapModel) {
        FragmentMapFavorites fragmentMapFavorites = new FragmentMapFavorites();
        Bundle bundle = new Bundle();
        bundle.putSerializable(getString(R.string.map_favorites_key), mapModel);
        fragmentMapFavorites.setArguments(bundle);
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragmentFavoritesContainer, fragmentMapFavorites);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

}
