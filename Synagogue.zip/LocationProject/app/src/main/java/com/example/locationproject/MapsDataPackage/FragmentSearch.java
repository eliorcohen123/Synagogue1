package com.example.locationproject.MapsDataPackage;

import android.Manifest;
import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.text.Html;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.locationproject.AsyncTaskPackage.GetMapsAsyncTaskHistory;
import com.example.locationproject.AsyncTaskPackage.GetMapsAsyncTaskSearch;
import com.example.locationproject.CustomAdapterPackage.MapCustomAdapterSearch;
import com.example.locationproject.DataAppPackage.MapDBHelperSearch;
import com.example.locationproject.DataAppPackage.MapModel;
import com.example.locationproject.R;

import java.util.ArrayList;

public class FragmentSearch extends Fragment {

    private static ArrayList<MapModel> mMapList;
    private static MapCustomAdapterSearch mAdapter;
    private static ListView mListView;
    private static MapDBHelperSearch mMapDBHelperSearch;
    private GetMapsAsyncTaskSearch mGetMapsAsyncTaskSearch;
    private static ProgressDialog mProgressDialogInternet;
    private static FragmentSearch mFragmentSearch;
    private GetMapsAsyncTaskHistory mGetMapsAsyncTaskHistory;  // AsyncTask for AddMovie to add movie to MainActivity
    private View mView;
    private Location location;
    private SwipeRefreshLayout swipeRefreshLayout;  // SwipeRe freshLayout of MainActivity
    private LocationManager locationManager;
    private Criteria criteria;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_search_layout, container, false);

        mListView = mView.findViewById(R.id.list);
        swipeRefreshLayout = mView.findViewById(R.id.swipe_containerFrag);  // ID of the SwipeRefreshLayout of MainActivity

        mFragmentSearch = this;

        mMapDBHelperSearch = new MapDBHelperSearch(getActivity());
        mMapList = mMapDBHelperSearch.getAllMaps();
        mAdapter = new MapCustomAdapterSearch(getActivity(), mMapList);
        registerForContextMenu(mListView);

        swipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.colorOrange));  // Colors of the SwipeRefreshLayout of MainActivity
        // Refresh the MovieDBHelper of app in ListView of MainActivity
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mMapDBHelperSearch = new MapDBHelperSearch(getActivity());
                mMapList = mMapDBHelperSearch.getAllMaps();
                mAdapter = new MapCustomAdapterSearch(getActivity(), mMapList);

                // Vibration for 0.1 second
                Vibrator vibrator = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vibrator.vibrate(100);
                }

                getActivity().finish();
                startActivity(getActivity().getIntent());  // Refresh activity

                Toast toast = Toast.makeText(getContext(), "The list are refreshed!", Toast.LENGTH_SHORT);
                View view = toast.getView();
                view.getBackground().setColorFilter(getResources().getColor(R.color.colorLightBlue), PorterDuff.Mode.SRC_IN);
                TextView text = view.findViewById(android.R.id.message);
                text.setTextColor(getResources().getColor(R.color.colorBrown));
                toast.show();  // Toast

                swipeRefreshLayout.setRefreshing(false);
            }
        });

        setHasOptionsMenu(true);
        myListView();
        return mView;
    }


    public void myListView() {
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                SearchInterface searchInterface = (SearchInterface) getActivity();
                searchInterface.onLocationItemClick(mMapList.get(position));
            }
        });
    }

    // Set movies in FragmentSearch
    public static void setMaps(ArrayList<MapModel> list) {
        mMapList = list;
        mAdapter.clear();
        mAdapter.addAll(list);
        mListView.setAdapter(mAdapter);
    }

    public boolean isConnected(Context context) {

        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            android.net.NetworkInfo wifi = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            android.net.NetworkInfo mobile = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

            if ((mobile != null && mobile.isConnectedOrConnecting()) || (wifi != null && wifi.isConnectedOrConnecting()))
                return true;
            else return false;
        } else
            return false;
    }

    public AlertDialog.Builder buildDialog(Context c) {
        AlertDialog.Builder builder = new AlertDialog.Builder(c);
        builder.setTitle("No Internet Connection");
        builder.setMessage("You need to have Mobile Data or wifi to access this. Press ok to Resume");

        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        return builder;
    }

    // Sets off the menu of activity_menu
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.activity_menu, menu);

        // SearchView of FragmentSearch
        final MenuItem menuItem = menu.findItem(R.id.action_search);
        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);

        // Change colors of the searchView upper panel
        menuItem.setOnActionExpandListener(new MenuItem.OnActionExpandListener() {
            @Override
            public boolean onMenuItemActionExpand(MenuItem item) {
                // Set styles for expanded state here
                if (((AppCompatActivity) getActivity()).getSupportActionBar() != null) {
                    ((AppCompatActivity) getActivity()).getSupportActionBar().setBackgroundDrawable(new ColorDrawable(Color.DKGRAY));
                }
                return true;
            }

            @Override
            public boolean onMenuItemActionCollapse(MenuItem item) {
                // Set styles for collapsed state here
                if (((AppCompatActivity) getActivity()).getSupportActionBar() != null) {
                    ((AppCompatActivity) getActivity()).getSupportActionBar().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                }
                return true;
            }
        });

        // Continued of SearchView of FragmentSearch
        final android.support.v7.widget.SearchView searchView = (android.support.v7.widget.SearchView) menuItem.getActionView();
        if (searchView != null) {
            searchView.setSearchableInfo(searchManager.getSearchableInfo((getActivity()).getComponentName()));
            searchView.setQueryHint(Html.fromHtml("<font color = #FFEA54>" + getResources().getString(R.string.hint) + "</font>"));
            searchView.setSubmitButtonEnabled(true);
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    if (!isConnected(getContext())) {
                        // Put AsyncTask in the ListView of MainActivity to execute the SQLiteHelper
                        mGetMapsAsyncTaskHistory = new GetMapsAsyncTaskHistory(mListView);
                        mGetMapsAsyncTaskHistory.execute(mMapDBHelperSearch);
                        buildDialog(getContext()).show();
                    } else {
                        // Search movies from that URL and put them in the SQLiteHelper
                        locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
                        criteria = new Criteria();
                        String provider = locationManager.getBestProvider(criteria, true);
                        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION);
                        }// TODO: Consider calling
//    ActivityCompat#requestPermissions
// here to request the missing permissions, and then overriding
//   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//                                          int[] grantResults)
// to handle the case where the user grants the permission. See the documentation
// for ActivityCompat#requestPermissions for more details.
                        if (provider != null) {
                            location = locationManager.getLastKnownLocation(provider);
                            // Search movies from that URL and put them in the SQLiteHelper
                            if (location != null) {
                                if (mAdapter != null) {
                                    mMapDBHelperSearch.deleteData();
                                    String urlQuery = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location="
                                            + location.getLatitude() + "," + location.getLongitude() +
                                            "&radius=50000&rankby=prominence&types=food|restaurant&keyword="
                                            + query +
                                            "&key=AIzaSyAsbM2AR1LlCHx3e9WoLzTfGkStBqhbH1M";
                                    mGetMapsAsyncTaskSearch = new GetMapsAsyncTaskSearch();
                                    mGetMapsAsyncTaskSearch.execute(urlQuery);
                                }
                            }
                        }
                    }
                    return true;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    return true;
                }
            });
        }
    }

    // Sets off the menu of list_menu
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo
            menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getActivity().getMenuInflater().inflate(R.menu.list_menu, menu);
    }

    // Options in the activity_menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_search:
                break;
            case R.id.nearByMe:
                if (!isConnected(getContext())) {
                    // Put AsyncTask in the ListView of MainActivity to execute the SQLiteHelper
                    mGetMapsAsyncTaskHistory = new GetMapsAsyncTaskHistory(mListView);
                    mGetMapsAsyncTaskHistory.execute(mMapDBHelperSearch);
                    buildDialog(getContext()).show();
                } else {
                    locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
                    criteria = new Criteria();
                    String provider = locationManager.getBestProvider(criteria, true);
                    if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION);
                    }// TODO: Consider calling
//    ActivityCompat#requestPermissions
// here to request the missing permissions, and then overriding
//   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//                                          int[] grantResults)
// to handle the case where the user grants the permission. See the documentation
// for ActivityCompat#requestPermissions for more details.
                    if (provider != null) {
                        location = locationManager.getLastKnownLocation(provider);
                        // Search movies from that URL and put them in the SQLiteHelper
                        if (location != null) {
                            if (mAdapter != null) {
                                mMapDBHelperSearch.deleteData();
                                String myQuery = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location="
                                        + location.getLatitude() + "," + location.getLongitude() +
                                        "&radius=5000&sensor=true&rankby=prominence&types=food|restaurant&keyword=&key=AIzaSyAsbM2AR1LlCHx3e9WoLzTfGkStBqhbH1M";
                                mGetMapsAsyncTaskSearch = new GetMapsAsyncTaskSearch();
                                mGetMapsAsyncTaskSearch.execute(myQuery);
                            }
                        }
                    }
                }
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    // Options in the list_menu
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int listPosition = info.position;
        switch (item.getItemId()) {
            case R.id.addMap:  // Edit the movies on MainActivity
                Intent intent = new Intent(getActivity(), AddMapFavorites.class);
                intent.putExtra(getString(R.string.map_add_from_internet), mMapList.get(listPosition));
                startActivity(intent);
                break;
            case R.id.shareIntent:
                String name = mMapList.get(listPosition).getName();
                String address = mMapList.get(listPosition).getVicinity();
                double lat = mMapList.get(listPosition).getLat();
                double lng = mMapList.get(listPosition).getLng();
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "Name: " + name + "\nAddress: " + address + "\nLatitude: " + lat + "\nLongitude: " + lng);
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
                break;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!isConnected(getContext())) {
            mMapDBHelperSearch = new MapDBHelperSearch(getActivity());
            mMapList = mMapDBHelperSearch.getAllMaps();
            mAdapter = new MapCustomAdapterSearch(getActivity(), mMapList);
            // Put AsyncTask in the ListView of MainActivity to execute the SQLiteHelper
            mGetMapsAsyncTaskHistory = new GetMapsAsyncTaskHistory(mListView);
            mGetMapsAsyncTaskHistory.execute(mMapDBHelperSearch);
            buildDialog(getContext()).show();
        } else {
            locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
            criteria = new Criteria();
            String provider = locationManager.getBestProvider(criteria, true);
            if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION);
            }// TODO: Consider calling
//    ActivityCompat#requestPermissions
// here to request the missing permissions, and then overriding
//   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//                                          int[] grantResults)
// to handle the case where the user grants the permission. See the documentation
// for ActivityCompat#requestPermissions for more details.
            if (provider != null) {
                location = locationManager.getLastKnownLocation(provider);
                // Search movies from that URL and put them in the SQLiteHelper
                if (location != null) {
                    if (mAdapter != null) {
                        mMapDBHelperSearch.deleteData();
                        String myQuery = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=" +
                                location.getLatitude() + "," + location.getLongitude() +
                                "&radius=5000&sensor=true&rankby=prominence&types=food|restaurant&keyword=&key=AIzaSyAsbM2AR1LlCHx3e9WoLzTfGkStBqhbH1M";
                        mGetMapsAsyncTaskSearch = new GetMapsAsyncTaskSearch();
                        mGetMapsAsyncTaskSearch.execute(myQuery);
                    }
                }
            }
        }
    }

    // stopShowingProgressBar
    public static void stopShowingProgressBar() {
        if (mProgressDialogInternet != null) {
            mProgressDialogInternet.dismiss();
            mProgressDialogInternet = null;
        }
    }

    // startShowingProgressBar
    public static void startShowingProgressBar() {
        mProgressDialogInternet = ProgressDialog.show(mFragmentSearch.getActivity(), "Loading...",
                "Please wait...", true);
        mProgressDialogInternet.show();
    }

}
