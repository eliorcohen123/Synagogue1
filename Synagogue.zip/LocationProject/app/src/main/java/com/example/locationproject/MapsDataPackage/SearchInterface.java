package com.example.locationproject.MapsDataPackage;

import com.example.locationproject.DataAppPackage.MapModel;

public interface SearchInterface {

    void onLocationItemClick(MapModel mapModel);
}
