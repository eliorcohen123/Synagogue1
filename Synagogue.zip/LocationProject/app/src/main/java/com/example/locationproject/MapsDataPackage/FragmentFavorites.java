package com.example.locationproject.MapsDataPackage;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.locationproject.AsyncTaskPackage.GetMapsAsyncTaskFavorites;
import com.example.locationproject.CustomAdapterPackage.MapCustomAdapterFavorites;
import com.example.locationproject.DataAppPackage.MapDBHelperFavorites;
import com.example.locationproject.DataAppPackage.MapModel;
import com.example.locationproject.MainAndOtherPackage.MainActivity;
import com.example.locationproject.R;

import java.util.ArrayList;

public class FragmentFavorites extends Fragment {

    private ArrayList<MapModel> mMapList;  // ArrayList of MovieModel
    private MapCustomAdapterFavorites mAdapter;  // CustomAdapter of MainActivity
    private GetMapsAsyncTaskFavorites mGetMapsAsyncTaskFavorites;  // AsyncTask for AddMovie to add movie to MainActivity
    private ListView mListView;  // ListView of MainActivity
    private MapDBHelperFavorites mMapDBHelperFavorites;  // The SQLiteHelper of the app
    private View mView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_favorites_layout, container, false);

        mListView = mView.findViewById(R.id.listFavorites);  // ID of the ListView of MainActivity

        mMapDBHelperFavorites = new MapDBHelperFavorites(getContext());  // Put the SQLiteHelper in MainActivity
        mMapList = mMapDBHelperFavorites.getAllMaps();  // Put the getAllMovies of SQLiteHelper in the ArrayList of MainActivity
        mAdapter = new MapCustomAdapterFavorites(getContext(), mMapList);  // Comparing the ArrayList of MainActivity to the CustomAdapter
        registerForContextMenu(mListView);

        // Put AsyncTask in the ListView of MainActivity to execute the SQLiteHelper
        mGetMapsAsyncTaskFavorites = new GetMapsAsyncTaskFavorites(mListView);
        mGetMapsAsyncTaskFavorites.execute(mMapDBHelperFavorites);

        setHasOptionsMenu(true);

        myListView();
        return mView;
    }


    // Sets off the menu of activity_menu
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.favorites_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    // Sets off the menu of list_menu
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getActivity().getMenuInflater().inflate(R.menu.favorites_list_menu, menu);
    }

    // Options in the activity_menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.intentMainActivity:
                Intent intentBackMainActivity = new Intent(getContext(), MainActivity.class);
                startActivity(intentBackMainActivity);
                break;
            case R.id.deleteAllDataFavorites:  // Delete all data of the app for delete all the data of the app
                Intent intentDeleteAllData = new Intent(getContext(), DeleteAllDataFavorites.class);
                startActivity(intentDeleteAllData);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    // Options in the list_menu
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int listPosition = info.position;
        switch (item.getItemId()) {
            case R.id.edit:  // Edit the movies on MainActivity
                Intent intent = new Intent(getContext(), EditMap.class);
                intent.putExtra(getString(R.string.map_id), mMapList.get(listPosition).getId());
                intent.putExtra(getString(R.string.map_edit), mMapList.get(listPosition));
                startActivity(intent);
                break;
            case R.id.shareIntent:
                String name = mMapList.get(listPosition).getName();
                String address = mMapList.get(listPosition).getVicinity();
                double lat = mMapList.get(listPosition).getLat();
                double lng = mMapList.get(listPosition).getLng();
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "Name: " + name + "\nAddress: " + address + "\nLatitude: " + lat + "\nLongitude: " + lng);
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
                break;
            case R.id.delete:  // Delete item(movie) on MainActivity
                mGetMapsAsyncTaskFavorites.deleteMovie(listPosition);
                mMapDBHelperFavorites.deleteMap(mMapList.get(listPosition));

                Intent intentDeleteData = new Intent(getContext(), DeleteMap.class);
                startActivity(intentDeleteData);
                break;
        }
        return super.onContextItemSelected(item);
    }

    public void myListView() {
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                SearchInterface searchInterface = (SearchInterface) getActivity();
                searchInterface.onLocationItemClick(mMapList.get(position));
            }
        });
    }

}
