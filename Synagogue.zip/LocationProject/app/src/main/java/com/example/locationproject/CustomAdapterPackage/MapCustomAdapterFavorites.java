package com.example.locationproject.CustomAdapterPackage;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.locationproject.DataAppPackage.MapModel;
import com.example.locationproject.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MapCustomAdapterFavorites extends ArrayAdapter<MapModel> {

    private Context mContext;  //Context
    private ArrayList<MapModel> mMovieList;  // ArrayList of MovieModel
    private Location location;
    private LocationManager locationManager;
    private Criteria criteria;

    public MapCustomAdapterFavorites(Context context_, ArrayList<MapModel> movie_) {
        super(context_, 0, movie_);
        mContext = context_;
        mMovieList = movie_;
    }

    @NonNull
    @Override
    public View getView(int position, @NonNull View convertView, @NonNull ViewGroup parent) {

        View listItem = convertView;
        if (listItem == null) {
            listItem = LayoutInflater.from(mContext).inflate(R.layout.movie_item_row_favorites, parent, false);
        }

        MapModel currentMap = getItem(position);  // Position of items

        // Put the image in image1
        if (currentMap != null) {  // If the position of the items not null
            locationManager = (LocationManager) getContext().getSystemService(Context.LOCATION_SERVICE);
            criteria = new Criteria();
            String provider = locationManager.getBestProvider(criteria, true);
            if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION);
            }// TODO: Consider calling
//    ActivityCompat#requestPermissions
// here to request the missing permissions, and then overriding
//   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//                                          int[] grantResults)
// to handle the case where the user grants the permission. See the documentation
// for ActivityCompat#requestPermissions for more details.
            if (provider != null) {
                location = locationManager.getLastKnownLocation(provider);
                if (location != null) {
                    float distanceKm;
                    float distanceMile;
                    android.location.Location locationA = new android.location.Location("Point A");
                    locationA.setLatitude(currentMap.getLat());
                    locationA.setLongitude(currentMap.getLng());
                    android.location.Location locationB = new Location("Point B");
                    locationB.setLatitude(location.getLatitude());
                    locationB.setLongitude(location.getLongitude());
                    distanceKm = locationA.distanceTo(locationB) / 1000;   // in km
                    distanceMile = (float) (locationA.distanceTo(locationB) / 1609.344);   // in miles

                    try {
                        ImageView image1 = listItem.findViewById(R.id.image3);
                        Picasso.get().load("https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference="
                                + currentMap.getPhoto_reference() +
                                "&key=AIzaSyAsbM2AR1LlCHx3e9WoLzTfGkStBqhbH1M").into(image1);
                    } catch (Exception e) {

                    }

                    // Put the text in name1
                    TextView name1 = listItem.findViewById(R.id.name3);
                    name1.setText(String.valueOf(currentMap.getName()));

                    // Put the text in address1
                    TextView address1 = listItem.findViewById(R.id.address3);
                    address1.setText(String.valueOf(currentMap.getVicinity()));

                    String distanceKm1 = null;
                    if (distanceKm < 1) {
                        int dis = (int) (distanceKm * 1000);
                        distanceKm1 = "\n" + "Meters: " + String.valueOf(dis);
                    } else if (distanceKm >= 1) {
                        String disM = String.format("%.2f", distanceKm);
                        distanceKm1 = "\n" + "Km: " + String.valueOf(disM);
                    }
                    TextView km1 = listItem.findViewById(R.id.kmMe3);
                    km1.setText(distanceKm1);

                    String disMile = String.format("%.2f", distanceMile);
                    TextView mile1 = listItem.findViewById(R.id.mileMe3);
                    mile1.setText("Miles: " + String.valueOf(disMile));
                }
            }
        }
        return listItem;
    }

}
