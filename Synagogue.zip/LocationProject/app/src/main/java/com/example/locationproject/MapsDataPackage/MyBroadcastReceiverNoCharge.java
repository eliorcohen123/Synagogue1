package com.example.locationproject.MapsDataPackage;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.locationproject.R;

public class MyBroadcastReceiverNoCharge extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

            Toast toastMute = Toast.makeText(context, "The phone are disconnected from charge!", Toast.LENGTH_SHORT);
            View viewMute = toastMute.getView();
            viewMute.getBackground().setColorFilter(context.getResources().getColor(R.color.colorLightBlue), PorterDuff.Mode.SRC_IN);
            TextView textMute = viewMute.findViewById(android.R.id.message);
            textMute.setTextColor(context.getResources().getColor(R.color.colorBrown));
            toastMute.show();  // Toast
    }

}
