package com.example.locationproject.AsyncTaskPackage;

import android.os.AsyncTask;
import android.widget.ListView;

import com.example.locationproject.CustomAdapterPackage.MapCustomAdapterSearch;
import com.example.locationproject.DataAppPackage.MapDBHelperSearch;
import com.example.locationproject.DataAppPackage.MapModel;

import java.util.ArrayList;

public class GetMapsAsyncTaskHistory extends AsyncTask<MapDBHelperSearch, Integer, ArrayList<MapModel>> {

    private ListView mListView;  // Initialize of ListView
    private MapCustomAdapterSearch mMovieCustomAdapterSearch;  // Initialize of MovieCustomAdapter
    private ArrayList<MapModel> mMapList;  // Initialize of ArrayList of MovieModel

    // AsyncTask to the ListView
    public GetMapsAsyncTaskHistory(ListView list) {
        mListView = list;
    }

    // DoInBackground of the ArrayList of MovieModel that put the getAllMovies in the SQLiteHelper in the ArrayList of MovieModel
    @Override
    protected ArrayList<MapModel> doInBackground(MapDBHelperSearch... mapDBHelperSearches) {
        MapDBHelperSearch myDb = mapDBHelperSearches[0];
        mMapList = myDb.getAllMaps();

        return mMapList;
    }

    // Delete movie
    public void deleteMovie(int mapPosition_) {
        mMovieCustomAdapterSearch.remove(mMapList.get(mapPosition_));
    }

    // execute to add movies manually
    @Override
    protected void onPostExecute(ArrayList<MapModel> mapModels) {
        super.onPostExecute(mapModels);
        mMovieCustomAdapterSearch = new MapCustomAdapterSearch(mListView.getContext(), mapModels);
        mListView.setAdapter(mMovieCustomAdapterSearch);
    }

}
