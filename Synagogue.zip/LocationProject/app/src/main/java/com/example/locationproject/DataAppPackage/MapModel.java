package com.example.locationproject.DataAppPackage;

import java.io.Serializable;
import java.util.List;

public class MapModel implements Serializable {

    private double lat;
    private double lng;
    private String vicinity;
    private String name;
    private String id;
    private String photo_reference;
    private List<Photos> photos;
    private Geometry geometry;

    public MapModel(String name, String vicinity, double lat, double lng, Geometry geometry, List<Photos> photos) {
        this.vicinity = vicinity;
        this.name = name;
        this.lat = lat;
        this.lng = lng;
        this.geometry = geometry;
        this.photos = photos;
        this.photo_reference = photos.get(0).getPhoto_reference();
    }


    public String getPhoto_reference() {
        return photos.get(0).getPhoto_reference();
    }

    public void setPhoto_reference(String photo_reference) {
        this.photos.get(0).setPhoto_reference(photo_reference);
    }

    public double getLng() {
        return geometry.getLocation().getLng();
    }

    public void setLng(double lng) {
        this.geometry.getLocation().setLng(lng);
    }

    public double getLat() {
        return geometry.getLocation().getLat();
    }

    public void setLat(double lat) {
        this.geometry.getLocation().setLat(lat);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getVicinity() {
        return vicinity;
    }

    public void setVicinity(String formatted_address) {
        this.vicinity = formatted_address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Photos> getPhotos() {
        return photos;
    }

    public void setPhotos(List<Photos> photos) {
        this.photos = photos;
    }

}
