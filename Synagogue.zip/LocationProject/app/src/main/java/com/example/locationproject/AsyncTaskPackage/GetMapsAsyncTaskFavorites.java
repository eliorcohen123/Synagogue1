package com.example.locationproject.AsyncTaskPackage;

import android.os.AsyncTask;
import android.widget.ListView;

import com.example.locationproject.CustomAdapterPackage.MapCustomAdapterFavorites;
import com.example.locationproject.DataAppPackage.MapDBHelperFavorites;
import com.example.locationproject.DataAppPackage.MapModel;

import java.util.ArrayList;

public class GetMapsAsyncTaskFavorites extends AsyncTask<MapDBHelperFavorites, Integer, ArrayList<MapModel>> {

    private ListView mListView;  // Initialize of ListView
    private MapCustomAdapterFavorites mMovieCustomAdapterFavorites;  // Initialize of MovieCustomAdapter
    private ArrayList<MapModel> mMapList;  // Initialize of ArrayList of MovieModel

    // AsyncTask to the ListView
    public GetMapsAsyncTaskFavorites(ListView list) {
        mListView = list;
    }

    // DoInBackground of the ArrayList of MovieModel that put the getAllMovies in the SQLiteHelper in the ArrayList of MovieModel
    @Override
    protected ArrayList<MapModel> doInBackground(MapDBHelperFavorites... mapDBHelperFavorites) {
        MapDBHelperFavorites myDb = mapDBHelperFavorites[0];
        mMapList = myDb.getAllMaps();

        return mMapList;
    }

    // Delete movie
    public void deleteMovie(int mapPosition_) {
        mMovieCustomAdapterFavorites.remove(mMapList.get(mapPosition_));
    }

    // execute to add movies manually
    @Override
    protected void onPostExecute(ArrayList<MapModel> mapModels) {
        super.onPostExecute(mapModels);
        mMovieCustomAdapterFavorites = new MapCustomAdapterFavorites(mListView.getContext(), mapModels);
        mListView.setAdapter(mMovieCustomAdapterFavorites);
    }

}
