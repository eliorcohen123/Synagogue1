package com.example.locationproject.MapsDataPackage;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.locationproject.R;

public class MapCustomActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_fragment);

    }

}
